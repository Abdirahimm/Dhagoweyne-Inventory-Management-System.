<?php
include "db.php";

// EDIT functionality
$edit_mode = false;
$order_id = '';
$product_name = '';
$quantity = '';
$price = '';
$total_price = '';
$employee_id = '';

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $order_id = intval($_GET['edit']);
    $result = mysqli_query($conn, "SELECT * FROM orders WHERE order_id = $order_id");
    if ($row = mysqli_fetch_assoc($result)) {
        $product_name = $row['product_name'];
        $quantity = $row['quantity'];
        $price = $row['price'];
        $total_price = $row['total_price'];
        $employee_id = $row['employee_id'] ?? '';
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $total_price = $quantity * $price;
    $employee_id = $_POST['employee_id'];

    if (isset($_POST['order_id']) && $_POST['order_id'] != '') {
        // Update
        $order_id = intval($_POST['order_id']);
        $query = "UPDATE orders SET product_name='$product_name', quantity='$quantity', price='$price', total_price='$total_price', employee_id='$employee_id' WHERE order_id=$order_id";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Order updated successfully!'); window.location.href='add_order.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // Insert
        $query = "INSERT INTO orders (product_name, quantity, price, total_price, employee_id) 
                  VALUES ('$product_name', '$quantity', '$price', '$total_price', '$employee_id')";
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Order added successfully!'); window.location.href='add_order.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $edit_mode ? 'Edit' : 'Register'; ?> Order</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .main.collapsed { margin-left: 0; }
        .order-card input[type="text"],
        .order-card input[type="number"],
        .order-card select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .order-card input[type="text"]:focus,
        .order-card input[type="number"]:focus,
        .order-card select:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .order-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .order-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .order-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .order-card .card-title {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="add_order.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>

    </a>

    <form method="POST" action="" class="order-card">
        <?php if ($edit_mode): ?>
            <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order_id); ?>">
        <?php endif; ?>

        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-bag" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    <?php echo $edit_mode ? 'Edit' : 'Register'; ?> Order
                </h3>


                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" required value="<?php echo htmlspecialchars($product_name); ?>">

                <label for="quantity">Quantity</label>
                <input type="number" id="quantity" name="quantity" required value="<?php echo htmlspecialchars($quantity); ?>">

                <label for="price">Price</label>
                <input type="number" id="price" name="price" required value="<?php echo htmlspecialchars($price); ?>">

                <label for="total_price">Total Price</label>
                <input type="number" id="total_price" name="total_price" value="<?php echo htmlspecialchars($total_price); ?>" readonly>

                <label for="employee_id">Employee ID</label>
                <input type="text" id="employee_id" name="employee_id" required value="<?php echo htmlspecialchars($employee_id); ?>">

                <button type="submit" style="margin-top:10px;"><?php echo $edit_mode ? 'Update Order' : 'Add Order'; ?></button>
            </div>
        </div>
    </form>

    <script>
        // Auto-calculate total price when quantity or price changes
        document.getElementById('quantity').addEventListener('input', calculateTotal);
        document.getElementById('price').addEventListener('input', calculateTotal);

        function calculateTotal() {
            var qty = parseFloat(document.getElementById('quantity').value) || 0;
            var price = parseFloat(document.getElementById('price').value) || 0;
            document.getElementById('total_price').value = qty * price;
        }
    </script>
</body>
</html>