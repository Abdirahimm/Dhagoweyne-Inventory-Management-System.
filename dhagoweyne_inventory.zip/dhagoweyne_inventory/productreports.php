<?php
session_start();
include "db.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Product Report</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #232526 0%, #414345 100%);
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            padding-top: 0;
            transition: left 0.3s, box-shadow 0.3s;
            text-align: center;
            box-shadow: 2px 0 12px rgba(0,0,0,0.10);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar img.logo {
            width: 90px;
            height: 90px;
            margin-bottom: 10px;
            margin-top: 18px;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 50%;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 8px;
        }
        .sidebar ul li a {
            color: #e3f2fd;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar ul li a i {
            font-size: 18px;
        }
        .sidebar ul li a:hover,
        .sidebar ul li.active a {
            background: #3a3a3a;
            color: #ffd600;
        }
        .sidebar .logout {
            margin-top: 35px;
        }
        .sidebar .logout a {
            color: #ff5252 !important;
            background: #fff0f0;
            border-radius: 6px;
            padding: 10px 28px;
            display: inline-block;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .logout a:hover {
            background: #ff1744;
            color: #fff !important;
        }
        #reportSub.show { display:block !important; }
        #reportSub li a {
            padding: 10px 10px 10px 35px;
            font-size: 15px;
            color: #e3f2fd;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #reportSub li a:hover {
            background: #3a3a3a;
            color: #ffd600;
        }
        .sidebar.hidden { left: -240px; }
        @media (max-width: 991.98px) {
            .sidebar { left: -240px; }
            .sidebar.active { left: 0; }
        }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #232526 0%, #414345 100%);
            color: #ffd600;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .topbar .menu-toggle {
            font-size: 24px;
            cursor: pointer;
            margin-right: 10px;
            background: none;
            border: none;
            color: #fff;
            display: flex;
            align-items: center;
        }
        @media (min-width: 992px) {
            .topbar .menu-toggle {
                display: none;
            }
        }
        .topbar .logo {
            display: flex;
            align-items: center;
        }
        .topbar .logo img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .main-content {
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #232526;
        }
        .back-button {
            display: block;
            width: 180px;
            margin: 0 auto 20px auto;
            padding: 10px;
            background: #ffd600;
            color: #232526;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            font-weight: bold;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .back-button:hover {
            background: #232526;
            color: #ffd600;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .table thead th {
            background: #232526 !important;
            color: #ffd600 !important;
            font-weight: bold;
        }
        #print-report {
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            font-weight: bold;
            border-radius: 5px;
            padding: 8px 16px;
            transition: background 0.2s, color 0.2s;
        }
        #print-report:hover {
            background: #232526;
            color: #ffd600;
        }
        @media (max-width: 991.98px) {
            .sidebar {
                left: -240px;
            }
            .sidebar.active {
                left: 0;
            }
            .main {
                margin-left: 0;
            }
        }
        @media print {
            #print-report,
            .topbar,
            .sidebar,
            .back-button {
                display: none !important;
            }
            .main {
                margin-left: 0 !important;
            }
            body {
                background: white !important;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <img src="image.png" alt="Profile" class="logo">
        <ul style="list-style:none; padding:0;">
            <li>
                <a href="dashboard_manager.php">
                    <i class="bi bi-person-badge"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="product.php">
                    <i class="bi bi-box-seam"></i>
                    Products
                </a>
            </li>
            <li>
                <a href="sale.php">
                    <i class="bi bi-cart"></i>
                    Sales
                </a>
            </li>
            <li>
                <a href="order.php">
                    <i class="bi bi-bag"></i>
                    Orders
                </a>
            </li>
            <li>
                <a href="supplier.php">
                    <i class="bi bi-truck"></i>
                    Suppliers
                </a>
            </li>
            <!-- REPORT DROPDOWN START -->
            <li style="position:relative;">
                <a href="#" onclick="event.preventDefault();document.getElementById('reportSub').classList.toggle('show');" style="cursor:pointer;">
                    <i class="bi bi-bar-chart"></i>
                    Report <i class="bi bi-caret-down-fill" style="margin-left:auto;"></i>
                </a>
                <ul id="reportSub" style="display:none;list-style:none;padding-left:30px;margin:0;background:none;">
                    <li>
                        <a href="productreports.php">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            Product Report
                        </a>
                    </li>
                </ul>
            </li>
            <!-- REPORT DROPDOWN END -->
        </ul>
        <div class="logout">
            <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>

    <div class="main" id="main">
        <div class="topbar">
            <button class="menu-toggle" id="menuToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="logo">
                <img src="image.png" alt="Logo">
                <span style="font-size: 1.2rem; font-weight: bold;">Product Report</span>
            </div>
            <div>
                <a href="logout.php" class="btn btn-danger" style="font-weight:bold;">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
        <div class="main-content">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h2 class="mb-0">Product Report</h2>
                <button id="print-report" onclick="window.print()">
                    <i class="bi bi-printer"></i> Print Report
                </button>
            </div>
            <div class="table-responsive text-nowrap">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Product ID</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Date</th>
                            <th>In Stock</th>
                            <th>Product Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM products ORDER BY product_id DESC";
                        $result = mysqli_query($conn, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row['product_id']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['category']) . "</td>";
                                echo "<td>$" . htmlspecialchars(number_format($row['price'], 2)) . "</td>";
                                echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['instock']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['product_type']) . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7' class='text-center text-muted'>No product records found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('menuToggle')?.addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        });
    </script>
</body>
</html>
