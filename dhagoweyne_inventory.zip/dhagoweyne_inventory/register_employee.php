<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_name = $_POST['employee_name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $shift = $_POST['shift'];
    $part = $_POST['part'];

    $query = "INSERT INTO employees (employee_name, age, gender, phone, shift, part) 
              VALUES ('$employee_name', '$age', '$gender', '$phone', '$shift', '$part')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Employee registered successfully!'); window.location.href='add_employee.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Employee</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .main.collapsed { margin-left: 0; }
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #232526 0%, #414345 100%);
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            padding-top: 0;
            transition: left 0.3s, box-shadow 0.3s;
            text-align: center;
            box-shadow: 2px 0 12px rgba(0,0,0,0.10);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar img.logo {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 10px;
            margin-top: 18px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 8px;
        }
        .sidebar ul li a {
            color: #e3f2fd;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar ul li a i {
            font-size: 18px;
        }
        .sidebar ul li a:hover,
        .sidebar ul li.active a {
            background: #3a3a3a;
            color: #ffd600;
        }
        .sidebar .logout {
            margin-top: 35px;
        }
        .sidebar .logout a {
            color: #ff5252 !important;
            background: #fff0f0;
            border-radius: 6px;
            padding: 10px 28px;
            display: inline-block;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .logout a:hover {
            background: #ff1744;
            color: #fff !important;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #232526 0%, #414345 100%);
            color: #ffd600;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .topbar .menu-toggle {
            font-size: 24px;
            cursor: pointer;
            margin-right: 10px;
            background: none;
            border: none;
            color: #fff;
            display: flex;
            align-items: center;
        }
        @media (min-width: 992px) {
            .topbar .menu-toggle {
                display: none;
            }
        }
        .topbar .logo {
            display: flex;
            align-items: center;
        }
        .topbar .logo img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .main-content {
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #232526;
        }
        .employee-card input[type="text"],
        .employee-card input[type="number"],
        .employee-card select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .employee-card input[type="text"]:focus,
        .employee-card input[type="number"]:focus,
        .employee-card select:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .employee-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .employee-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .employee-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .employee-card .card-title {
            margin-bottom: 18px;
        }
        @media (max-width: 991.98px) {
            .sidebar { left: -240px; }
            .sidebar.active { left: 0; }
            .main { margin-left: 0; }
        }
    </style>
</head>
<body>
    <!-- Sidebar (optional, add your navigation here if needed) -->
    <!-- Back Button -->
    <a href="add_employee.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
    
    </a>

    <form method="POST" action="" class="employee-card">
        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-person-badge" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    Register Employee
                </h3>

                <label for="employee_name">Employee Name</label>
                <input type="text" id="employee_name" name="employee_name" required>

                <label for="age">Age</label>
                <input type="number" id="age" name="age" required>

                <label for="gender">Gender</label>
                <select id="gender" name="gender" required>
                    <option value="">-- Select Gender --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>

                <label for="phone">Phone</label>
                <input type="text" id="phone" name="phone" required>

                <label for="shift">Shift</label>
                <select id="shift" name="shift" required>
                    <option value="">-- Select Shift --</option>
                    <option value="Morning">Morning</option>
                    <option value="Evening">Evening</option>
                </select>

                <label for="part">Part</label>
                <select id="part" name="part" required>
                    <option value="">-- Select Part --</option>
                    <option value="Store">Store</option>
                    <option value="Cashier">Cashier</option>
                    <option value="Sales">Sales</option>
                </select>

                <button type="submit" style="margin-top:10px;">Register Employee</button>
            </div>
        </div>
    </form>
</body>
</html>