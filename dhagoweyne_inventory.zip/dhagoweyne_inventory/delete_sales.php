<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM sales WHERE sales_id = $id";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Sale record deleted successfully.'); window.location.href='sales.php';</script>";
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request.";
}
?>
