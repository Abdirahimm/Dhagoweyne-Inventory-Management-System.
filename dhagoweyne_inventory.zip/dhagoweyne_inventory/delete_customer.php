<?php
include "db.php";

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM customers WHERE customer_id = $id";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Customer deleted successfully!'); window.location.href='add_customer.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>