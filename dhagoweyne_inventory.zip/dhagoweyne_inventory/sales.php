<?php
include "db.php";
session_start();

// Delete Sale
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $query = "DELETE FROM sales WHERE sales_id = $id";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Sale deleted successfully!'); window.location.href='sales.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}

// Save Sale
if (isset($_POST['BtnSave'])) {
    $product_name = $_POST['TxtProduct_Name'];
    $quantity = $_POST['TxtQuantity'];
    $price = $_POST['TxtPrice'];
    $total_price = $_POST['TxtTotal_Price'];
    $sales_date = $_POST['TxtSales_Date'];
    mysqli_query($conn, "INSERT INTO sales (product_name, quantity, price, total_price, sales_date)
        VALUES ('$product_name', '$quantity', '$price', '$total_price', '$sales_date')");
}

// Update Sale
if (isset($_POST['BtnUpdate'])) {
    $id = $_POST['sales_id'];
    $product_name = $_POST['TxtProduct_Name'];
    $quantity = $_POST['TxtQuantity'];
    $price = $_POST['TxtPrice'];
    $total_price = $_POST['TxtTotal_Price'];
    $sales_date = $_POST['TxtSales_Date'];
    mysqli_query($conn, "UPDATE sales SET  
        product_name='$product_name', quantity='$quantity', price='$price',
        total_price='$total_price', sales_date='$sales_date'
        WHERE sales_id=$id");
}

// Edit Sale
$update = false;
$sales_id = "";
$product_name = "";
$quantity = "";
$price = "";
$total_price = "";
$sales_date = "";

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $update = true;
    $record = mysqli_query($conn, "SELECT * FROM sales WHERE sales_id=$id");
    $n = mysqli_fetch_array($record);
    $sales_id = $n['sales_id'];
    $product_name = $n['product_name'];
    $quantity = $n['quantity'];
    $price = $n['price'];
    $total_price = $n['total_price'];
    $sales_date = $n['sales_date'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #232526 0%, #414345 100%);
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            padding-top: 0;
            transition: left 0.3s, box-shadow 0.3s;
            text-align: center;
            box-shadow: 2px 0 12px rgba(0,0,0,0.10);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar img.logo {
            width: 90px;
            height: 90px;
            margin-bottom: 10px;
            margin-top: 18px;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 50%; /* Ku dar si ay u noqoto circle */
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 8px;
        }
        .sidebar ul li a {
            color: #e3f2fd;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar ul li a i {
            font-size: 18px;
        }
        .sidebar ul li a:hover,
        .sidebar ul li.active a {
            background: #3a3a3a;
            color: #ffd600;
        }
        .sidebar .logout {
            margin-top: 35px;
        }
        .sidebar .logout a {
            color: #ff5252 !important;
            background: #fff0f0;
            border-radius: 6px;
            padding: 10px 28px;
            display: inline-block;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .logout a:hover {
            background: #ff1744;
            color: #fff !important;
        }
        #reportSub.show { display:block !important; }
        #reportSub li a {
            padding: 10px 10px 10px 35px;
            font-size: 15px;
            color: #e3f2fd;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #reportSub li a:hover {
            background: #3a3a3a;
            color: #ffd600;
        }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #232526 0%, #414345 100%);
            color: #ffd600;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .topbar .logo {
            display: flex;
            align-items: center;
        }
        .topbar .logo img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .topbar .profile-menu {
            position: relative;
            display: inline-block;
        }
        .topbar .profile-menu button {
            color: #ffd600;
        }
        .topbar .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 5px;
            margin-top: 10px;
            z-index: 100;
        }
        .topbar .dropdown-menu a {
            padding: 10px 20px;
            display: block;
            color: #333;
            text-decoration: none;
        }
        .topbar .dropdown-menu a:hover {
            background-color: #f5f5f5;
        }
        .main-content {
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #232526;
        }
        .register-button {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background: #ffd600;
            color: #232526;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
            font-weight: bold;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .register-button:hover {
            background: #232526;
            color: #ffd600;
        }
        .table-responsive {
            margin-top: 20px;
        }
        .table thead th {
            background: #232526 !important;
            color: #ffd600 !important;
            font-weight: bold;
        }
        /* Search button */
        .btn-primary {
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            font-weight: bold;
            transition: background 0.2s, color 0.2s;
        }
        .btn-primary:hover {
            background: #232526;
            color: #ffd600;
        }
        /* Edit button */
        .btn-success {
            background: linear-gradient(90deg, #00c853 0%, #b9f6ca 100%);
            color: #232526;
            border: none;
            font-weight: bold;
            transition: background 0.2s, color 0.2s;
        }
        .btn-success:hover {
            background: #232526;
            color: #00c853;
        }
        /* Delete button */
        .btn-danger {
            background: linear-gradient(90deg, #d50000 0%, #ff8a80 100%);
            color: #fff;
            border: none;
            font-weight: bold;
            transition: background 0.2s, color 0.2s;
        }
        .btn-danger:hover {
            background: #232526;
            color: #ff5252;
        }
        @media (max-width: 991.98px) {
            .sidebar {
                left: -240px;
            }
            .sidebar.active {
                left: 0;
            }
            .main {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <img src="image.png" alt="Profile" class="logo">
        <ul style="list-style:none; padding:0;">
            <li>
                <a href="dashboard_admin.php">
                    <i class="bi bi-person-badge"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="add_customer.php">
                    <i class="bi bi-people"></i>
                    Customers
                </a>
            </li>
            <li>
                <a href="add_employee.php">
                    <i class="bi bi-person-badge"></i>
                    Employees
                </a>
            </li>
            <li>
                <a href="add_product.php">
                    <i class="bi bi-box-seam"></i>
                    Products
                </a>
            </li>
            <li>
                <a href="sales.php">
                    <i class="bi bi-cart"></i>
                    Sales
                </a>
            </li>
            <li>
                <a href="add_order.php">
                    <i class="bi bi-bag"></i>
                    Orders
                </a>
            </li>
            <li>
                <a href="add_supplier.php">
                    <i class="bi bi-truck"></i>
                    Suppliers
                </a>
            </li>
            <li>
                <a href="add_user.php">
                    <i class="bi bi-person-plus"></i>
                    Users
                </a>
            </li>
            <!-- REPORT DROPDOWN START -->
            <li style="position:relative;">
                <a href="#" onclick="event.preventDefault();document.getElementById('reportSub').classList.toggle('show');" style="cursor:pointer;">
                    <i class="bi bi-bar-chart"></i>
                    Report <i class="bi bi-caret-down-fill" style="margin-left:auto;"></i>
                </a>
                <ul id="reportSub" style="display:none;list-style:none;padding-left:30px;margin:0;background:none;">
                    <li>
                        <a href="employereport.php">
                            <i class="bi bi-file-earmark-person"></i>
                            Employee Report
                        </a>
                    </li>
                    <li>
                        <a href="productreport.php">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            Product Report
                        </a>
                    </li>
                </ul>
            </li>
            <!-- REPORT DROPDOWN END -->
            <li>
                <a href="backup.php">
                    <i class="bi bi-cloud-arrow-down"></i>
                    Backup
                </a>
            </li>
        </ul>
        <div class="logout">
            <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>

    <div class="main" id="main">
        <div class="topbar">
            <button class="menu-toggle" id="menuToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="logo">
                <img src="image.png" alt="Logo">
                <span style="font-size: 1.2rem; font-weight: bold;">Sales Dashboard</span>
            </div>
            <div>
                <a href="logout.php" class="btn btn-danger" style="font-weight:bold;">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
        <div class="main-content">
            <h2>Sales List</h2>
            <!-- Search Form -->
            <form method="get" class="mb-3" style="max-width:350px;">
                <div class="input-group">
                    <input type="text" name="search" class="form-control" placeholder="Search sale..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button class="btn btn-primary" type="submit"><i class="bi bi-search"></i> Search</button>
                </div>
            </form>
            <!-- Register Sale Button -->
            <a href="add_sales.php" class="register-button" style="cursor:pointer;">
                <i class="bi bi-cart"></i> Add New Sale
            </a>
            <div class="table-responsive text-nowrap">
                <table class="table datatable" style="width:100%">
                    <thead>
                        <tr>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Sales ID</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Product Name</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Quantity</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Price</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Total Price</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Sales Date</th>
                            <th style="background:#0d47a1; color:#fff; font-weight:bold;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $where = "";
                        if (!empty($_GET['search'])) {
                            $search = mysqli_real_escape_string($conn, $_GET['search']);
                            $where = "WHERE product_name LIKE '%$search%' OR quantity LIKE '%$search%' OR price LIKE '%$search%' OR total_price LIKE '%$search%' OR sales_date LIKE '%$search%'";
                        }
                        $results = mysqli_query($conn, "SELECT * FROM sales $where ORDER BY sales_id DESC");
                        $counter = 1;
                        if (mysqli_num_rows($results) > 0) {
                            while ($row = mysqli_fetch_assoc($results)) {
                                echo "<tr>";
                                echo "<td>" . $counter++ . "</td>";
                                echo "<td>" . htmlspecialchars($row['product_name']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['quantity']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['total_price']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['sales_date']) . "</td>";
                                echo "<td style='display:flex;justify-content:center;gap:8px;'>
                                    <a href='register_sale.php?edit=" . $row['sales_id'] . "' class='btn btn-sm btn-success' title='Edit'><i class='bi bi-pencil-square'></i></a>
                                    <a href='sales.php?delete=" . $row['sales_id'] . "' class='btn btn-sm btn-danger' title='Delete' onclick=\"return confirm('Delete this sale?');\"><i class='bi bi-trash'></i></a>
                                </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No sales found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        // Sidebar toggle for mobile
        document.getElementById('menuToggle')?.addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            var main = document.getElementById('main');
            sidebar.classList.toggle('active');
            main?.classList.toggle('collapsed');
        });
    </script>
</body>
</html>
