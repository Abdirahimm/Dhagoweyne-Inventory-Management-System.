<?php
include "db.php";

$item_id = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT) ?: 0;
$item_name = '';
$category = '';
$quantity = 0;
$price = '';
$supplier = '';
$update = $item_id > 0;

if ($update) {
    $statement = $conn->prepare("SELECT item_name, category, quantity, price, supplier FROM items WHERE item_id = ?");
    $statement->bind_param("i", $item_id);
    $statement->execute();
    $result = $statement->get_result();
    $item = $result->fetch_assoc();
    $statement->close();

    if (!$item) {
        header("Location: items.php");
        exit;
    }

    $item_name = $item['item_name'];
    $category = $item['category'];
    $quantity = $item['quantity'];
    $price = $item['price'];
    $supplier = $item['supplier'] ?? '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $item_id = filter_input(INPUT_POST, 'item_id', FILTER_VALIDATE_INT) ?: 0;
    $item_name = trim($_POST['item_name'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $supplier = trim($_POST['supplier'] ?? '');
    $update = $item_id > 0;

    if ($item_name === '' || $category === '' || $quantity === false || $quantity < 0 || $price === false || $price < 0) {
        $error = 'Please fill in all required fields with valid values.';
    } elseif ($update) {
        $statement = $conn->prepare("UPDATE items SET item_name = ?, category = ?, quantity = ?, price = ?, supplier = ? WHERE item_id = ?");
        $statement->bind_param("ssidsi", $item_name, $category, $quantity, $price, $supplier, $item_id);
        $statement->execute();
        $statement->close();
        header("Location: items.php");
        exit;
    } else {
        $statement = $conn->prepare("INSERT INTO items (item_name, category, quantity, price, supplier, date_added) VALUES (?, ?, ?, ?, ?, CURDATE())");
        $statement->bind_param("ssids", $item_name, $category, $quantity, $price, $supplier);
        $statement->execute();
        $statement->close();
        header("Location: items.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $update ? 'Edit Item' : 'Add Item'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #e3f0ff, #f8fafc); font-family: 'Segoe UI', sans-serif; }
        .item-card { max-width: 520px; margin: 50px auto; border: 0; border-radius: 14px; }
        .item-card h2 { color: #0d47a1; }
        .form-control:focus { border-color: #0d47a1; box-shadow: 0 0 0 .2rem rgba(13, 71, 161, .12); }
        .btn-item { background: #ffd600; color: #232526; font-weight: 700; border: 0; }
        .btn-item:hover { background: #232526; color: #ffd600; }
    </style>
</head>
<body>
    <a href="items.php" class="btn btn-item m-4"><i class="bi bi-arrow-left"></i> Back to Items</a>
    <div class="card shadow item-card">
        <div class="card-body p-4">
            <h2 class="text-center mb-4"><i class="bi bi-list-check"></i> <?php echo $update ? 'Edit Item' : 'Add New Item'; ?></h2>
            <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <form method="post">
                <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
                <div class="mb-3"><label class="form-label" for="item_name">Item Name</label><input class="form-control" id="item_name" name="item_name" value="<?php echo htmlspecialchars($item_name); ?>" required></div>
                <div class="mb-3"><label class="form-label" for="category">Category</label><input class="form-control" id="category" name="category" value="<?php echo htmlspecialchars($category); ?>" required></div>
                <div class="row">
                    <div class="col-md-6 mb-3"><label class="form-label" for="quantity">Quantity</label><input class="form-control" type="number" min="0" id="quantity" name="quantity" value="<?php echo htmlspecialchars((string)$quantity); ?>" required></div>
                    <div class="col-md-6 mb-3"><label class="form-label" for="price">Price</label><input class="form-control" type="number" min="0" step="0.01" id="price" name="price" value="<?php echo htmlspecialchars((string)$price); ?>" required></div>
                </div>
                <div class="mb-4"><label class="form-label" for="supplier">Supplier</label><input class="form-control" id="supplier" name="supplier" value="<?php echo htmlspecialchars($supplier); ?>"></div>
                <button class="btn btn-item w-100" type="submit"><i class="bi bi-save"></i> <?php echo $update ? 'Update Item' : 'Save Item'; ?></button>
            </form>
        </div>
    </div>
</body>
</html>
