<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $price = $_POST['price'];
    $total_price = $quantity * $price;
    $sales_date = date('Y-m-d');

    $query = "INSERT INTO sales (product_name, quantity, price, total_price, sales_date) 
              VALUES ('$product_name', '$quantity', '$price', '$total_price', '$sales_date')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Sales record added successfully!'); window.location.href='sales.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Sales</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .sales-card input[type="text"],
        .sales-card input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .sales-card input[type="text"]:focus,
        .sales-card input[type="number"]:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .sales-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .sales-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .sales-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .sales-card .card-title {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="sales.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
    
    </a>

    <form method="POST" action="" class="sales-card">
        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-cart-plus" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    Add New Sale
                </h3>

                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" required>

                <label for="quantity">Quantity</label>
                <input type="number" id="quantity" name="quantity" required>

                <label for="price">Price</label>
                <input type="number" id="price" name="price" required>

                <button type="submit" style="margin-top:10px;">Add Sale</button>
            </div>
        </div>
    </form>

</body>
</html>
