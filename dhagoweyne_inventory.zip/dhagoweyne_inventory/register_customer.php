<?php
include "db.php";

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $id");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $customer_name = $row['customer_name'];
        $age = $row['age'];
        $sex = $row['sex'];
        $address = $row['address'];
        $city = $row['city'];
        $phone = $row['phone'];
    } else {
        echo "<script>alert('Customer not found!'); window.location.href='add_customer.php';</script>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['customer_id']) && !empty($_POST['customer_id'])) {
        $id = $_POST['customer_id'];
        $customer_name = $_POST['TxtCustomer_Name'];
        $age = $_POST['TxtAge'];
        $sex = $_POST['CmbSex'];
        $address = $_POST['TxtAddress'];
        $city = $_POST['CmbCity'];
        $phone = $_POST['TxtPhone'];

        $query = "UPDATE customers SET 
                  customer_name = '$customer_name', 
                  age = '$age', 
                  sex = '$sex', 
                  address = '$address', 
                  city = '$city', 
                  phone = '$phone' 
                  WHERE customer_id = $id";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Customer updated successfully!'); window.location.href='add_customer.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "<script>alert('Invalid customer ID!'); window.location.href='add_customer.php';</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['customer_id'])) {
    $customer_name = $_POST['TxtCustomer_Name'];
    $age = $_POST['TxtAge'];
    $sex = $_POST['CmbSex'];
    $address = $_POST['TxtAddress'];
    $city = $_POST['CmbCity'];
    $phone = $_POST['TxtPhone'];

    mysqli_query($conn, "INSERT INTO customers (customer_name, age, sex, address, city, phone, date_added)
        VALUES ('$customer_name', '$age', '$sex', '$address', '$city', '$phone', CURDATE())");

    echo "<script>alert('Customer registered successfully!'); window.location.href='add_customer.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($id) ? 'Edit' : 'Register'; ?> Customer</title>
    <!-- ✅ Bootstrap Icons CDN -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }

        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }

        .main.collapsed { margin-left: 0; }

        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #232526 0%, #414345 100%);
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            padding-top: 0;
            transition: left 0.3s, box-shadow 0.3s;
            text-align: center;
            box-shadow: 2px 0 12px rgba(0,0,0,0.10);
            z-index: 1000;
            overflow-y: auto;
        }

        .sidebar img.logo {
            width: 90px;
            height: 90px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 10px;
            margin-top: 18px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .sidebar ul li {
            margin-bottom: 8px;
        }

        .sidebar ul li a {
            color: #e3f2fd;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }

        .sidebar ul li a i {
            font-size: 18px;
        }

        .sidebar ul li a:hover,
        .sidebar ul li.active a {
            background: #3a3a3a;
            color: #ffd600;
        }

        .sidebar .logout {
            margin-top: 35px;
        }

        .sidebar .logout a {
            color: #ff5252 !important;
            background: #fff0f0;
            border-radius: 6px;
            padding: 10px 28px;
            display: inline-block;
            transition: background 0.2s, color 0.2s;
        }

        .sidebar .logout a:hover {
            background: #ff1744;
            color: #fff !important;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #232526 0%, #414345 100%);
            color: #ffd600;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }

        .topbar .menu-toggle {
            font-size: 24px;
            cursor: pointer;
            margin-right: 10px;
            background: none;
            border: none;
            color: #fff;
            display: flex;
            align-items: center;
        }

        @media (min-width: 992px) {
            .topbar .menu-toggle {
                display: none;
            }
        }

        .topbar .logo {
            display: flex;
            align-items: center;
        }

        .topbar .logo img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .main-content {
            padding: 20px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #232526;
        }

        form {
            max-width: 400px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }

        @media (max-width: 991.98px) {
            .sidebar { left: -240px; }
            .sidebar.active { left: 0; }
            .main { margin-left: 0; }
        }

        .customer-card input[type="text"],
        .customer-card input[type="number"],
        .customer-card select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .customer-card input[type="text"]:focus,
        .customer-card input[type="number"]:focus,
        .customer-card select:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .customer-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .customer-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .customer-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .customer-card .card-title {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
        <a href="add_customer.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
        
    </a>


    <form method="POST" action="" class="customer-card">
        <?php if (isset($id)): ?>
            <input type="hidden" name="customer_id" value="<?php echo $id; ?>">
        <?php endif; ?>

        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-person-circle" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    <?php echo isset($id) ? 'Edit' : 'Register'; ?> Customer
                </h3>

                <label for="TxtCustomer_Name">Customer Name</label>
                <input type="text" id="TxtCustomer_Name" name="TxtCustomer_Name" value="<?php echo isset($customer_name) ? $customer_name : ''; ?>" required>

                <label for="TxtAge">Age</label>
                <input type="number" id="TxtAge" name="TxtAge" value="<?php echo isset($age) ? $age : ''; ?>" required>

                <label for="CmbSex">Sex</label>
                <select id="CmbSex" name="CmbSex" required>
                    <option value="Male" <?php if (isset($sex) && $sex == "Male") echo "selected"; ?>>Male</option>
                    <option value="Female" <?php if (isset($sex) && $sex == "Female") echo "selected"; ?>>Female</option>
                </select>

                <label for="TxtAddress">Address</label>
                <input type="text" id="TxtAddress" name="TxtAddress" value="<?php echo isset($address) ? $address : ''; ?>" required>

                <label for="CmbCity">City</label>
                <select id="CmbCity" name="CmbCity" required>
                    <option value="Hargeisa" <?php if (isset($city) && $city == "Hargeisa") echo "selected"; ?>>Hargeisa</option>
                    <option value="Borama" <?php if (isset($city) && $city == "Borama") echo "selected"; ?>>Borama</option>
                    <option value="Berbera" <?php if (isset($city) && $city == "Berbera") echo "selected"; ?>>Berbera</option>
                </select>

                <label for="TxtPhone">Phone</label>
                <input type="text" id="TxtPhone" name="TxtPhone" value="<?php echo isset($phone) ? $phone : ''; ?>" required>

                <button type="submit" style="margin-top:10px;"><?php echo isset($id) ? 'Update' : 'Register'; ?> Customer</button>
            </div>
        </div>
    </form>

</body>
</html>