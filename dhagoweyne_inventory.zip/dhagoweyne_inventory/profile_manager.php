<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

// Get user profile info
$username = $_SESSION['username'];
$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = isset($_POST['full_name']) ? $_POST['full_name'] : '';
    $role = isset($_POST['role']) ? $_POST['role'] : '';

    $update = $conn->prepare("UPDATE users SET full_name = ?, role = ? WHERE username = ?");
    $update->bind_param("sss", $full_name, $role, $username);
    if ($update->execute()) {
        // Redirect to dashboard after successful update
        header("Location: dashboard_admin.php");
        exit();
    } else {
        $message = "Failed to update profile.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: #f0f2f5;
            font-family: 'Segoe UI', sans-serif;
        }
        .profile-card {
            max-width: 400px;
            margin: 60px auto;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 12px rgba(13,71,161,0.08);
            padding: 30px 25px;
            text-align: center;
        }
        .profile-card .bi-person-circle {
            font-size: 70px;
            color: #0d47a1;
            margin-bottom: 10px;
        }
        .profile-card h4 {
            margin-bottom: 5px;
        }
        .profile-card .role {
            color: #1565c0;
            font-size: 15px;
            margin-bottom: 15px;
        }
        .profile-card .btn {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <!-- Profile card-ka waa laga saaray halkan -->
        <h2>User Profile</h2>
        <?php if (isset($message)): ?>
            <div class="alert alert-info"> <?= $message ?> </div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="full_name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="full_name" name="full_name"
                    value="<?= isset($user['full_name']) ? htmlspecialchars($user['full_name']) : '' ?>" required>
            </div>
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username"
                    value="<?= isset($user['username']) ? htmlspecialchars($user['username']) : '' ?>" readonly>
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
            <a href="dashboard_admin.php" class="btn btn-secondary ms-2"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>