<?php
session_start();
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'manager') {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manager Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .sidebar {
            width: 240px;
            height: 100vh;
            background: linear-gradient(180deg, #232526 0%, #414345 100%);
            position: fixed;
            top: 0;
            left: 0;
            color: #fff;
            padding-top: 0;
            transition: left 0.3s, box-shadow 0.3s;
            text-align: center;
            box-shadow: 2px 0 12px rgba(0,0,0,0.10);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar img.logo {
            width: 90px;
            height: 90px;
            margin-bottom: 10px;
            margin-top: 18px;
            object-fit: cover;
            border: 3px solid #fff;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 50%;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .sidebar ul li {
            margin-bottom: 8px;
        }
        .sidebar ul li a {
            color: #e3f2fd;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar ul li a i {
            font-size: 18px;
        }
        .sidebar ul li a:hover,
        .sidebar ul li.active a {
            background: #3a3a3a;
            color: #ffd600;
        }
        .sidebar .logout {
            margin-top: 35px;
        }
        .sidebar .logout a {
            color: #ff5252 !important;
            background: #fff0f0;
            border-radius: 6px;
            padding: 10px 28px;
            display: inline-block;
            transition: background 0.2s, color 0.2s;
        }
        .sidebar .logout a:hover {
            background: #ff1744;
            color: #fff !important;
        }
        .sidebar.hidden { left: -240px; }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .main.collapsed { margin-left: 0; }
        @media (max-width: 991.98px) {
            .sidebar { left: -240px; }
            .sidebar.active { left: 0; }
            .main {
                margin-left: 0;
            }
        }
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background: linear-gradient(90deg, #232526 0%, #414345 100%);
            color: #ffd600;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .topbar .menu-toggle {
            font-size: 24px;
            cursor: pointer;
            margin-right: 10px;
            background: none;
            border: none;
            color: #fff;
        }
        .topbar .logo {
            display: flex;
            align-items: center;
        }
        .topbar .logo img {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            margin-right: 10px;
        }
        .topbar .logo span {
            color: #ffd600;
        }
        .topbar .profile-menu {
            position: relative;
            display: inline-block;
        }
        .topbar .profile-menu button {
            background: none;
            border: none;
            cursor: pointer;
            color: #ffd600;
            font-weight: bold;
        }
        .topbar .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 5px;
            margin-top: 10px;
            z-index: 100;
        }
        .topbar .dropdown-menu a {
            padding: 10px 20px;
            display: block;
            color: #333;
            text-decoration: none;
        }
        .topbar .dropdown-menu a:hover {
            background-color: #f5f5f5;
        }
        .dashboard-card {
            background: #fff;
            border-radius: 18px;
            padding: 36px 22px 28px 22px;
            text-align: center;
            position: relative;
            transition: box-shadow 0.2s, transform 0.2s;
            min-height: 220px;
            display: flex;
            flex-direction: column;
            align-items: center;
            box-shadow: 0 4px 24px rgba(35,37,38,0.07);
        }
        .dashboard-card:hover {
            box-shadow: 0 12px 32px rgba(65,67,69,0.13);
            transform: translateY(-6px) scale(1.025);
        }
        .dashboard-icon {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            margin-bottom: 18px;
            box-shadow: 0 2px 8px rgba(255,214,0,0.10);
            background: linear-gradient(135deg, #ffd600 0%, #fffde4 100%);
            color: #232526;
        }
        .dashboard-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #232526;
            margin-bottom: 8px;
        }
        .dashboard-link {
            margin-top: auto;
            display: inline-block;
            padding: 7px 20px;
            border-radius: 20px;
            background: #f8fafc;
            color: #232526;
            font-weight: 500;
            text-decoration: none;
            transition: background 0.2s, color 0.2s;
            font-size: 15px;
            border: 1px solid #ffd600;
        }
        .dashboard-link:hover {
            background: #ffd600;
            color: #232526;
            border-color: #ffd600;
        }
        .sidebar-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
            border-radius: 50%;
            margin-right: 12px;
            font-size: 1.2rem;
            box-shadow: 0 2px 8px rgba(13,71,161,0.08);
            flex-shrink: 0;
        }
        #reportSub.show { display:block !important; }
        #reportSub li a {
            padding: 10px 10px 10px 35px;
            font-size: 15px;
            color: #e3f2fd;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #reportSub li a:hover {
            background: #3a3a3a;
            color: #ffd600;
        }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <img src="image.png" alt="Profile" class="logo">
        <ul style="list-style:none; padding:0;">
            <li>
                <a href="dashboard_manager.php">
                    <i class="bi bi-person-badge"></i>
                    Dashboard
                </a>
            </li>
            <li>
                <a href="product.php">
                    <i class="bi bi-box-seam"></i>
                    Products
                </a>
            </li>
            <li>
                <a href="items.php">
                    <i class="bi bi-list-check"></i>
                    Items
                </a>
            </li>
            <li>
                <a href="sale.php">
                    <i class="bi bi-cart"></i>
                    Sales
                </a>
            </li>
            <li>
                <a href="order.php">
                    <i class="bi bi-bag"></i>
                    Orders
                </a>
            </li>
            <li>
                <a href="supplier.php">
                    <i class="bi bi-truck"></i>
                    Suppliers
                </a>
            </li>
            <!-- REPORT DROPDOWN START -->
            <li style="position:relative;">
                <a href="#" onclick="event.preventDefault();document.getElementById('reportSub').classList.toggle('show');" style="cursor:pointer;">
                    <i class="bi bi-bar-chart"></i>
                    Report <i class="bi bi-caret-down-fill" style="margin-left:auto;"></i>
                </a>
                <ul id="reportSub" style="display:none;list-style:none;padding-left:30px;margin:0;background:none;">
                    <li>
                        <a href="productreports.php">
                            <i class="bi bi-file-earmark-bar-graph"></i>
                            Product Report
                        </a>
                    </li>
                </ul>
            </li>
            <!-- REPORT DROPDOWN END -->
        </ul>
        <div class="logout">
            <a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a>
        </div>
    </div>

    <div class="main" id="main">
        <div class="topbar">
            <button class="menu-toggle" id="menuToggle">
                <i class="bi bi-list"></i>
            </button>
            <div class="logo">
                <img src="image.png" alt="Logo">
                <span style="font-size: 1.2rem; font-weight: bold;">Manager Dashboard</span>
            </div>
            <div class="profile-menu">
                <button onclick="toggleDropdown()">
                    <i class="bi bi-person-circle"></i> <?php echo $_SESSION['username'] ?? 'Manager'; ?> <i class="bi bi-caret-down-fill"></i>
                </button>
                <div class="dropdown-menu" id="profileDropdown">
                    <a href="profile_manager.php" onclick="closeDropdown()">Profile</a>
                    <a href="logout.php" onclick="closeDropdown()">Logout</a>
                </div>
            </div>
        </div>

        <div class="container py-4">
            <div class="row g-4 justify-content-center">
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="dashboard-card shadow-sm">
                        <div class="dashboard-icon bg-warning text-white">
                            <i class="bi bi-box-seam"></i>
                        </div>
                        <div class="dashboard-title">Product Management</div>
                        <a href="product.php" class="dashboard-link">Manage Products</a>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="dashboard-card shadow-sm">
                        <div class="dashboard-icon bg-danger text-white">
                            <i class="bi bi-cart"></i>
                        </div>
                        <div class="dashboard-title">Sales</div>
                        <a href="sale.php" class="dashboard-link">View Sales</a>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="dashboard-card shadow-sm">
                        <div class="dashboard-icon bg-info text-white">
                            <i class="bi bi-bag"></i>
                        </div>
                        <div class="dashboard-title">Orders</div>
                        <a href="order.php" class="dashboard-link">View Orders</a>
                    </div>
                </div>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                    <div class="dashboard-card shadow-sm">
                        <div class="dashboard-icon bg-secondary text-white">
                            <i class="bi bi-truck"></i>
                        </div>
                        <div class="dashboard-title">Suppliers</div>
                        <a href="supplier.php" class="dashboard-link">View Suppliers</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('menuToggle').onclick = function() {
            var sidebar = document.getElementById('sidebar');
            var main = document.getElementById('main');
            sidebar.classList.toggle('hidden');
            main.classList.toggle('collapsed');
        };
        function toggleDropdown() {
            var menu = document.getElementById("profileDropdown");
            menu.style.display = (menu.style.display === "block") ? "none" : "block";
        }
        function closeDropdown() {
            document.getElementById("profileDropdown").style.display = "none";
        }
        window.onclick = function(event) {
            if (!event.target.matches('.profile-menu button') && !event.target.closest('.profile-menu')) {
                var dropdowns = document.getElementsByClassName("dropdown-menu");
                for (var i = 0; i < dropdowns.length; i++) {
                    dropdowns[i].style.display = "none";
                }
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>