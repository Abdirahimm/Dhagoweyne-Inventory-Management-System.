<?php
include "db.php";

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM users WHERE user_id = $id");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $username = $row['username'];
        $password = $row['password'];
        $gender = $row['gender'];
        $role = $row['role'];
    } else {
        echo "<script>alert('User not found!'); window.location.href='add_user.php';</script>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['user_id'];
    $username = $_POST['TxtUsername'];
    $password = $_POST['TxtPassword'];
    $gender = $_POST['CmbGender'];
    $role = $_POST['CmbRole'];

    $query = "UPDATE users SET 
              username = '$username', 
              password = '$password', 
              gender = '$gender', 
              role = '$role' 
              WHERE user_id = $id";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('User updated successfully!'); window.location.href='add_user.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f4f4f4;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #0d47a1;
        }

        form {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }

        .back-button {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background: #6c757d;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-button:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>

    <h2>Edit User</h2>

    <form method="POST" action="">
        <input type="hidden" name="user_id" value="<?php echo $id; ?>">

        <label for="TxtUsername">Username</label>
        <input type="text" id="TxtUsername" name="TxtUsername" value="<?php echo $username; ?>" required>

        <label for="TxtPassword">Password</label>
        <input type="password" id="TxtPassword" name="TxtPassword" value="<?php echo $password; ?>" required>

        <label for="CmbGender">Gender</label>
        <select id="CmbGender" name="CmbGender" required>
            <option value="Male" <?php if ($gender == "Male") echo "selected"; ?>>Male</option>
            <option value="Female" <?php if ($gender == "Female") echo "selected"; ?>>Female</option>
        </select>

        <label for="CmbRole">Role</label>
        <select id="CmbRole" name="CmbRole" required>
            <option value="Admin" <?php if ($role == "Admin") echo "selected"; ?>>Admin</option>
            <option value="Staff" <?php if ($role == "Staff") echo "selected"; ?>>Staff</option>
        </select>

        <button type="submit">Update User</button>
    </form>

    <a href="add_user.php" class="back-button">Back to User List</a>

</body>
</html>