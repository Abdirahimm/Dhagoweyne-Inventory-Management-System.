<?php
include "db.php";

$conn->query("CREATE TABLE IF NOT EXISTS items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    category VARCHAR(255) NOT NULL,
    quantity INT NOT NULL DEFAULT 0,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    supplier VARCHAR(255) DEFAULT NULL,
    date_added DATE NOT NULL
)");

if (isset($_GET['delete'])) {
    $item_id = filter_input(INPUT_GET, 'delete', FILTER_VALIDATE_INT);
    if ($item_id) {
        $statement = $conn->prepare("DELETE FROM items WHERE item_id = ?");
        $statement->bind_param("i", $item_id);
        $statement->execute();
        $statement->close();
    }
    header("Location: items.php");
    exit;
}

$search = trim($_GET['search'] ?? '');
if ($search !== '') {
    $like = "%$search%";
    $statement = $conn->prepare("SELECT * FROM items WHERE item_name LIKE ? OR category LIKE ? OR supplier LIKE ? ORDER BY item_id DESC");
    $statement->bind_param("sss", $like, $like, $like);
    $statement->execute();
    $items = $statement->get_result();
} else {
    $items = $conn->query("SELECT * FROM items ORDER BY item_id DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Items</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background: linear-gradient(135deg, #e3f0ff, #f8fafc); font-family: 'Segoe UI', sans-serif; }
        .topbar { background: linear-gradient(90deg, #232526, #414345); color: #ffd600; padding: 16px 24px; }
        .content { padding: 28px; }
        .table thead th { background: #232526; color: #ffd600; }
        .btn-item { background: #ffd600; color: #232526; border: 0; font-weight: 700; }
        .btn-item:hover { background: #232526; color: #ffd600; }
        .empty { padding: 35px; text-align: center; color: #6c757d; }
    </style>
</head>
<body>
    <div class="topbar d-flex justify-content-between align-items-center">
        <h2 class="mb-0"><i class="bi bi-list-check"></i> Items</h2>
        <a href="dashboard_admin.php" class="btn btn-outline-light"><i class="bi bi-speedometer2"></i> Dashboard</a>
    </div>
    <main class="content">
        <div class="d-flex flex-wrap gap-2 justify-content-between align-items-center mb-4">
            <form method="get" class="d-flex" style="max-width: 390px; width: 100%;">
                <input class="form-control" type="search" name="search" placeholder="Search items..." value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-item ms-2" type="submit"><i class="bi bi-search"></i></button>
            </form>
            <a href="register_item.php" class="btn btn-item"><i class="bi bi-plus-lg"></i> Add Item</a>
        </div>
        <div class="table-responsive bg-white shadow-sm rounded">
            <table class="table table-hover align-middle mb-0">
                <thead><tr><th>No</th><th>Item Name</th><th>Category</th><th>Quantity</th><th>Price</th><th>Supplier</th><th>Date</th><th>Actions</th></tr></thead>
                <tbody>
                <?php if ($items && $items->num_rows > 0): $counter = 1; while ($item = $items->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                        <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                        <td><?php echo htmlspecialchars(number_format((float)$item['price'], 2)); ?></td>
                        <td><?php echo htmlspecialchars($item['supplier'] ?? ''); ?></td>
                        <td><?php echo htmlspecialchars($item['date_added']); ?></td>
                        <td class="text-nowrap">
                            <a class="btn btn-sm btn-success" href="register_item.php?edit=<?php echo $item['item_id']; ?>" title="Edit"><i class="bi bi-pencil-square"></i></a>
                            <a class="btn btn-sm btn-danger" href="items.php?delete=<?php echo $item['item_id']; ?>" title="Delete" onclick="return confirm('Delete this item?');"><i class="bi bi-trash"></i></a>
                        </td>
                    </tr>
                <?php endwhile; else: ?>
                    <tr><td class="empty" colspan="8">No items found.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
