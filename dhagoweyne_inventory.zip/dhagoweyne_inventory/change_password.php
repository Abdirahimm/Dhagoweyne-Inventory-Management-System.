<?php
include "db.php";

$message = "";
$error = "";

if (isset($_POST['BtnChange'])) {
    $username = trim($_POST['TxtUsername']);
    $new_password = trim($_POST['TxtNewPassword']);
    $confirm_password = trim($_POST['TxtConfirmPassword']);

    // Step Three: Check validity (Y/N)
    if (empty($username) || empty($new_password) || empty($confirm_password)) {
        $error = "All fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        $check_user = mysqli_query($conn, "SELECT * FROM users WHERE username='$username'");
        if (mysqli_num_rows($check_user) > 0) {
            // Step Six: Confirm
            mysqli_query($conn, "UPDATE users SET password='$new_password' WHERE username='$username'");
            $message = "Password changed successfully.";
        } else {
            $error = "Username not found.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Change Password</title>
    <style>
        body {
            font-family: Arial;
            background: #f9f9f9;
            padding: 30px;
        }

        h2 {
            text-align: center;
            color: #444;
        }

        form {
            width: 500px;
            margin: auto;
            background: #fff;
            padding: 20px;
            box-shadow: 0 0 10px #ccc;
            border-radius: 10px;
        }

        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .buttons {
            margin-top: 15px;
            text-align: center;
        }

        .buttons input {
            padding: 10px 20px;
            margin: 5px;
            border: none;
            background: #007bff;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .buttons input:hover {
            background: #0056b3;
        }

        .message {
            text-align: center;
            margin-top: 10px;
            font-weight: bold;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>

    <h2>Change Password</h2>

    <form method="POST" action="">
        <label for="TxtUsername">Username:</label>
        <input type="text" name="TxtUsername" id="TxtUsername" required>

        <label for="TxtNewPassword">New Password:</label>
        <input type="password" name="TxtNewPassword" id="TxtNewPassword" required>

        <label for="TxtConfirmPassword">Confirm Password:</label>
        <input type="password" name="TxtConfirmPassword" id="TxtConfirmPassword" required>

        <div class="buttons">
            <input type="submit" name="BtnChange" value="Change">
            <input type="reset" value="Clear">
        </div>
    </form>

    <?php if ($message != ""): ?>
        <div class="message success"><?php echo $message; ?></div>
    <?php endif; ?>

    <?php if ($error != ""): ?>
        <div class="message error"><?php echo $error; ?></div>
    <?php endif; ?>

</body>
</html>
