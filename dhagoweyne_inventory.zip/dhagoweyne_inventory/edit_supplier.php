<?php
include "db.php";

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM suppliers WHERE supplier_id = $id");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $supplier_name = $row['supplier_name'];
        $supplier_phone = $row['supplier_phone'];
        $city = $row['city'];
        $amount = $row['amount'];
    } else {
        echo "<script>alert('Supplier not found!'); window.location.href='add_supplier.php';</script>";
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['supplier_id'];
    $supplier_name = $_POST['TxtSupplier_Name'];
    $supplier_phone = $_POST['TxtPhone'];
    $city = $_POST['TxtCity'];
    $amount = $_POST['TxtAmount'];

    $query = "UPDATE suppliers SET 
              supplier_name = '$supplier_name', 
              supplier_phone = '$supplier_phone', 
              city = '$city', 
              amount = '$amount' 
              WHERE supplier_id = $id";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Supplier updated successfully!'); window.location.href='add_supplier.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Supplier</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f4f4f4;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 28px;
            color: #0d47a1;
        }

        form {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }

        .back-button {
            display: block;
            width: 200px;
            margin: 20px auto;
            padding: 10px;
            background: #6c757d;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-button:hover {
            background: #5a6268;
        }
    </style>
</head>
<body>

    <h2>Edit Supplier</h2>

    <form method="POST" action="">
        <input type="hidden" name="supplier_id" value="<?php echo $id; ?>">

        <label for="TxtSupplier_Name">Supplier Name</label>
        <input type="text" id="TxtSupplier_Name" name="TxtSupplier_Name" value="<?php echo $supplier_name; ?>" required>

        <label for="TxtPhone">Phone</label>
        <input type="text" id="TxtPhone" name="TxtPhone" value="<?php echo $supplier_phone; ?>" required>

        <label for="TxtCity">City</label>
        <input type="text" id="TxtCity" name="TxtCity" value="<?php echo $city; ?>" required>

        <label for="TxtAmount">Amount</label>
        <input type="number" id="TxtAmount" name="TxtAmount" value="<?php echo $amount; ?>" required>

        <button type="submit">Update Supplier</button>
    </form>

    <a href="add_supplier.php" class="back-button">Back to Supplier List</a>

</body>
</html>