<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $role = $_POST['role'];

    $query = "INSERT INTO users (username, password, gender, role) 
              VALUES ('$username', '$password', '$gender', '$role')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('User registered successfully!'); window.location.href='add_user.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .user-card input[type="text"],
        .user-card input[type="password"],
        .user-card select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .user-card input[type="text"]:focus,
        .user-card input[type="password"]:focus,
        .user-card select:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .user-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .user-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .user-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .user-card .card-title {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="add_user.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
        Back to Users
    </a>

    <form method="POST" action="" class="user-card">
        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-person-plus" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    Register User
                </h3>

                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>

                <label for="gender">Gender</label>
                <select id="gender" name="gender" required>
                    <option value="">-- Select Gender --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>

                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="">-- Select Role --</option>
                    <option value="Admin">Admin</option>
                    <option value="Staff">Staff</option>
                </select>

                <button type="submit" style="margin-top:10px;">Register User</button>
            </div>
        </div>
    </form>

</body>
</html>