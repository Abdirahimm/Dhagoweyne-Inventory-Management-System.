<?php
include "db.php";

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM customers WHERE customer_id = $id");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $customer_name = $row['customer_name'];
        $age = $row['age'];
        $sex = $row['sex'];
        $address = $row['address'];
        $city = $row['city'];
        $phone = $row['phone'];
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['customer_id'];
    $customer_name = $_POST['TxtCustomer_Name'];
    $age = $_POST['TxtAge'];
    $sex = $_POST['CmbSex'];
    $address = $_POST['TxtAddress'];
    $city = $_POST['CmbCity'];
    $phone = $_POST['TxtPhone'];

    $query = "UPDATE customers SET 
        customer_name='$customer_name', age='$age', sex='$sex', 
        address='$address', city='$city', phone='$phone' 
        WHERE customer_id=$id";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Customer updated successfully!'); window.location.href='add_customer.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Sale</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .form-container {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 400px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #0d47a1;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background: #1565c0;
        }

        .back-button {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            background: #f44336;
            color: white;
            text-align: center;
            text-decoration: none;
            border-radius: 5px;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .back-button:hover {
            background: #d32f2f;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Sale</h2>
        <form method="POST">
            <label for="product_name">Product Name:</label>
            <input type="text" id="product_name" name="product_name" value="<?php echo $row['product_name']; ?>" required>

            <label for="quantity">Quantity:</label>
            <input type="number" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" required>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" value="<?php echo $row['price']; ?>" required>

            <button type="submit">Update Sale</button>
        </form>
        <a href="sales.php" class="back-button">Back to Sales</a>
    </div>
</body>
</html>