<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Dhagoweyne System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }

        .login-card {
            border-radius: 15px;
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.1);
            padding: 30px;
            background-color: #ffffff;
            color: #232526;
        }

        .form-control,
        .form-select {
            background-color: #f3f4f6;
            border: 1px solid #ddd;
            color: #232526;
        }

        .form-control::placeholder {
            color: #888;
        }

        .form-label {
            color: #232526;
            font-weight: 500;
        }

        .footer-text {
            text-align: center;
            font-size: 14px;
            color: #666;
            margin-top: 20px;
        }

        .btn-primary {
            background-color: #ffd600;
            border: 1px solid #ffd600;
            color: #232526;
            font-weight: 600;
        }

        .btn-primary:hover {
            background-color: #ffeb3b;
            border-color: #ffeb3b;
            color: #000;
        }

        .logo {
            max-width: 80px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="col-md-5 col-sm-10">
            <div class="login-card p-4">
                <img src="image.png" alt="Logo" class="logo">
                <h3 class="mb-4 text-center" style="font-weight:bold;">Dhagoweyne Inventory Login</h3>
                <form action="login_process.php" method="POST">
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" required placeholder="Enter username">
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required placeholder="Enter password">
                    </div>
                    <div class="mb-3">
                        <label for="role" class="form-label">Role</label>
                        <select class="form-select" id="role" name="role" required>
                            <option value="">-- Select Role --</option>
                            <option value="admin">Admin</option>
                            <option value="manager">Manager</option>
                        </select>
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>
                <div class="footer-text">&copy; Dhagoweyne Inventory System</div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS (optional for dropdowns, modals, etc.) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
