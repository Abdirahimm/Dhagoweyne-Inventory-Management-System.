<?php
include "db.php";

$product_id = "";
$product_name = "";
$category = "";
$price = "";
$instock = "";
$product_type = "";

// Check if editing
if (isset($_GET['edit'])) {
    $product_id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM products WHERE product_id = $product_id");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $product_name = $row['product_name'];
        $category = $row['category'];
        $price = $row['price'];
        $instock = $row['instock'];
        $product_type = $row['product_type'];
    } else {
        echo "<script>alert('Product not found!'); window.location.href='add_product.php';</script>";
        exit;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $instock = $_POST['instock'];
    $product_type = $_POST['product_type'];

    $query = "UPDATE products SET 
              product_name = '$product_name', 
              category = '$category', 
              price = '$price', 
              instock = '$instock', 
              product_type = '$product_type' 
              WHERE product_id = $product_id";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Product updated successfully!'); window.location.href='add_product.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f4f4f4;
        }

        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-button i {
            margin-right: 5px;
        }

        .back-button:hover {
            background: #5a6268;
        }

        form {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="add_product.php" class="back-button"><i class="bi bi-arrow-left"></i> Back to Products</a>

    <h2 style="text-align: center;">Edit Product</h2>

    <form method="POST" action="">
        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">

        <label for="product_name">Product Name</label>
        <input type="text" id="product_name" name="product_name" value="<?php echo $product_name; ?>" required>

        <label for="category">Category</label>
        <input type="text" id="category" name="category" value="<?php echo $category; ?>" required>

        <label for="price">Price</label>
        <input type="number" id="price" name="price" value="<?php echo $price; ?>" required>

        <label for="instock">Instock</label>
        <input type="number" id="instock" name="instock" value="<?php echo $instock; ?>" required>

        <label for="product_type">Product Type</label>
        <input type="text" id="product_type" name="product_type" value="<?php echo $product_type; ?>" required>

        <button type="submit">Update Product</button>
    </form>

</body>
</html>