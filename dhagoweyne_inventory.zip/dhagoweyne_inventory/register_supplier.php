<?php
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $supplier_name = $_POST['TxtSupplier_Name'];
    $supplier_phone = $_POST['TxtPhone'];
    $city = $_POST['TxtCity'];
    $amount = $_POST['TxtAmount'];

    $query = "INSERT INTO suppliers (supplier_name, supplier_phone, city, amount) 
              VALUES ('$supplier_name', '$supplier_phone', '$city', '$amount')";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Supplier added successfully!'); window.location.href='add_supplier.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Supplier</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .supplier-card input[type="text"],
        .supplier-card input[type="number"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .supplier-card input[type="text"]:focus,
        .supplier-card input[type="number"]:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .supplier-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .supplier-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .supplier-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .supplier-card .card-title {
            margin-bottom: 18px;
        }

        .back-button {
            display: inline-block;
            margin: 20px 0 0 30px;
            padding: 10px 18px;
            background: #ffd600;
            color: #232526;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
            transition: background 0.3s;
        }

        .back-button:hover {
            background: #e0c200;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="add_supplier.php" class="back-button">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
    
    </a>

    <form method="POST" action="" class="supplier-card">
        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-truck" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    Register Supplier
                </h3>

                <label for="TxtSupplier_Name">Supplier Name</label>
                <input type="text" id="TxtSupplier_Name" name="TxtSupplier_Name" required>

                <label for="TxtPhone">Phone</label>
                <input type="text" id="TxtPhone" name="TxtPhone" required>

                <label for="TxtCity">City</label>
                <input type="text" id="TxtCity" name="TxtCity" required>

                <label for="TxtAmount">Amount</label>
                <input type="number" id="TxtAmount" name="TxtAmount" required>

                <button type="submit" style="margin-top:10px;">Add Supplier</button>
            </div>
        </div>
    </form>

</body>
</html>