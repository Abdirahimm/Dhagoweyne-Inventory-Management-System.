<?php
session_start();
include "db.php";

$username = $_POST['username'];
$password = $_POST['password'];
$role = strtolower($_POST['role']); // ka dhig lowercase si uu u waafaqo database-ka

$sql = "SELECT * FROM users WHERE username=? AND password=? AND role=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $username, $password, $role);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $_SESSION['username'] = $username;
    $_SESSION['role'] = $role;

    if ($role === 'admin') {
        header("Location: dashboard_admin.php");
    } elseif ($role === 'manager') {
        header("Location: dashboard_manager.php");
    } else {
        // role invalid or unknown
        $_SESSION['error'] = "Invalid role.";   $_SESSION['error'] = "Invalid role.";
        header("Location: login.php");der("Location: login.php");
    }
    exit();
} else {
    echo "<script>alert('Login failed! Please check your credentials.'); window.location.href='login.php';</script>";   echo "<script>alert('Login failed! Please check your credentials.'); window.location.href='login.php';</script>";
    exit();    exit();


}
