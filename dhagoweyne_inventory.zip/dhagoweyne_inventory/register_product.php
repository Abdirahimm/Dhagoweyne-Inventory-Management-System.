<?php
include "db.php";

// Create products table if it doesn't exist
$query = "CREATE TABLE IF NOT EXISTS products (
    product_id INT AUTO_INCREMENT PRIMARY KEY,
    product_name VARCHAR(255) NOT NULL,
    category VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    instock INT NOT NULL,
    product_type VARCHAR(255) NOT NULL,
    date_added DATE NOT NULL
)";

if (!mysqli_query($conn, $query)) {
    die("Error creating table: " . mysqli_error($conn));
}

$product_id = "";
$product_name = "";
$category = "";
$price = "";
$instock = "";
$product_type = "";
$update = false;

// Check if editing
if (isset($_GET['edit'])) {
    $product_id = $_GET['edit'];
    $result = mysqli_query($conn, "SELECT * FROM products WHERE product_id = $product_id");
    if ($result) {
        $row = mysqli_fetch_assoc($result);
        $product_name = $row['product_name'];
        $category = $row['category'];
        $price = $row['price'];
        $instock = $row['instock'];
        $product_type = $row['product_type'];
        $update = true;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $category = $_POST['category'];
    $price = $_POST['price'];
    $instock = $_POST['instock'];
    $product_type = $_POST['product_type'];

    if ($update) {
        // Update existing product
        $query = "UPDATE products SET 
                  product_name = '$product_name', 
                  category = '$category', 
                  price = '$price', 
                  instock = '$instock', 
                  product_type = '$product_type' 
                  WHERE product_id = $product_id";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Product updated successfully!'); window.location.href='add_product.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        // Insert new product
        $date_added = date('Y-m-d');
        $query = "INSERT INTO products (product_name, category, price, instock, product_type, date_added) 
                  VALUES ('$product_name', '$category', '$price', '$instock', '$product_type', '$date_added')";

        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Product added successfully!'); window.location.href='add_product.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $update ? "Edit Product" : "Register Product"; ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        body {
            background: linear-gradient(135deg, #e3f0ff 0%, #f8fafc 100%);
            font-family: 'Segoe UI', sans-serif;
        }
        .main {
            margin-left: 240px;
            transition: margin-left 0.3s;
        }
        .main.collapsed { margin-left: 0; }
        .product-card input[type="text"],
        .product-card input[type="number"],
        .product-card select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 6px;
            background: #f8fafc;
            font-size: 15px;
            transition: border 0.2s;
        }
        .product-card input[type="text"]:focus,
        .product-card input[type="number"]:focus,
        .product-card select:focus {
            border: 1.5px solid #0d47a1;
            outline: none;
            background: #fff;
        }
        .product-card label {
            font-weight: 600;
            color: #232526;
            margin-bottom: 6px;
        }
        .product-card button {
            width: 100%;
            padding: 10px;
            background: linear-gradient(90deg, #ffd600 0%, #ffe066 100%);
            color: #232526;
            border: none;
            border-radius: 6px;
            font-size: 17px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(35,37,38,0.08);
        }
        .product-card button:hover {
            background: #232526;
            color: #ffd600;
        }
        .product-card .card-title {
            margin-bottom: 18px;
        }
    </style>
</head>
<body>

    <!-- Back Button -->
    <a href="add_product.php" class="back-button" style="display:inline-block;margin:20px 0 0 30px;padding:10px 18px;background:#ffd600;color:#232526;text-decoration:none;border-radius:5px;font-size:16px;font-weight:bold;box-shadow:0 2px 8px rgba(35,37,38,0.08);transition:background 0.3s;">
        <i class="bi bi-arrow-left-circle" style="font-size:20px;vertical-align:middle;margin-right:6px;"></i>
        Back to Products
    </a>

    <form method="POST" action="" class="product-card">
        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">

        <div class="card shadow" style="border-radius:16px; border:none; max-width:430px; margin:30px auto 0 auto; background: #fff;">
            <div class="card-body" style="padding:32px 28px;">
                <h3 class="card-title" style="text-align:center; color:#0d47a1; margin-bottom:22px;">
                    <i class="bi bi-box-seam" style="font-size:2.2rem; color:#ffd600;"></i><br>
                    <?php echo $update ? "Edit Product" : "Register Product"; ?>
                </h3>

                <label for="product_name">Product Name</label>
                <input type="text" id="product_name" name="product_name" value="<?php echo $product_name; ?>" required>

                <label for="category">Category</label>
                <input type="text" id="category" name="category" value="<?php echo $category; ?>" required>

                <label for="price">Price</label>
                <input type="number" id="price" name="price" value="<?php echo $price; ?>" required>

                <label for="instock">Instock</label>
                <input type="number" id="instock" name="instock" value="<?php echo $instock; ?>" required>

                <label for="product_type">Product Type</label>
                <input type="text" id="product_type" name="product_type" value="<?php echo $product_type; ?>" required>

                <button type="submit" style="margin-top:10px;"><?php echo $update ? "Update Product" : "Add Product"; ?></button>
            </div>
        </div>
    </form>

</body>
</html>