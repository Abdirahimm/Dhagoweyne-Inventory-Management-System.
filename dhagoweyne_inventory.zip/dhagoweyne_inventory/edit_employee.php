<?php
include "db.php";

$employee_id = "";
$employee_name = "";
$age = "";
$gender = "";
$phone = "";
$shift = "";
$part = "";

// Check if editing
if (isset($_GET['id'])) {
    $employee_id = $_GET['id'];
    $result = mysqli_query($conn, "SELECT * FROM employees WHERE employee_id = $employee_id");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $employee_name = $row['employee_name'];
        $age = $row['age'];
        $gender = $row['gender'];
        $phone = $row['phone'];
        $shift = $row['shift'];
        $part = $row['part'];
    } else {
        echo "<script>alert('Employee not found!'); window.location.href='add_employee.php';</script>";
        exit;
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $employee_id = $_POST['employee_id'];
    $employee_name = $_POST['employee_name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $shift = $_POST['shift'];
    $part = $_POST['part'];

    $query = "UPDATE employees SET 
              employee_name = '$employee_name', 
              age = '$age', 
              gender = '$gender', 
              phone = '$phone', 
              shift = '$shift', 
              part = '$part' 
              WHERE employee_id = $employee_id";

    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Employee updated successfully!'); window.location.href='add_employee.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f4f4f4;
        }

        .back-button {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 15px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 16px;
        }

        .back-button:hover {
            background: #5a6268;
        }

        form {
            max-width: 400px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            width: 100%;
            padding: 10px;
            background: #0d47a1;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #1565c0;
        }
    </style>
</head>
<body>

    <a href="add_employee.php" class="back-button">Back to Employee Dashboard</a>

    <h2 style="text-align: center;">Edit Employee</h2>

    <form method="POST" action="">
        <input type="hidden" name="employee_id" value="<?php echo $employee_id; ?>">

        <label for="employee_name">Employee Name</label>
        <input type="text" id="employee_name" name="employee_name" value="<?php echo $employee_name; ?>" required>

        <label for="age">Age</label>
        <input type="number" id="age" name="age" value="<?php echo $age; ?>" required>

        <label for="gender">Gender</label>
        <select id="gender" name="gender" required>
            <option value="Male" <?php if ($gender == "Male") echo "selected"; ?>>Male</option>
            <option value="Female" <?php if ($gender == "Female") echo "selected"; ?>>Female</option>
        </select>

        <label for="phone">Phone</label>
        <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>" required>

        <label for="shift">Shift</label>
        <select id="shift" name="shift" required>
            <option value="Morning" <?php if ($shift == "Morning") echo "selected"; ?>>Morning</option>
            <option value="Evening" <?php if ($shift == "Evening") echo "selected"; ?>>Evening</option>
        </select>

        <label for="part">Part</label>
        <select id="part" name="part" required>
            <option value="Store" <?php if ($part == "Store") echo "selected"; ?>>Store</option>
            <option value="Cashier" <?php if ($part == "Cashier") echo "selected"; ?>>Cashier</option>
            <option value="Sales" <?php if ($part == "Sales") echo "selected"; ?>>Sales</option>
        </select>

        <button type="submit">Update Employee</button>
    </form>

</body>
</html>